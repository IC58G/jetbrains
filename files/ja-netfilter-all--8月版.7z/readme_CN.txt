2022年8月版本----by 凉心不败

VM地址:Help--Edit Custom VM Options...

参数-javaagent:路径/ja-netfilter-all/ja-netfilter/ja-netfilter.jar=jetbrains

无法正常启动访达地址：
Mac os：/Users/用户名/Library/Application Support/JetBrains/软件版本/软件名.vmoptions
Windwos：软件目录下/软件名.vmoptions

汉化包：
https://plugins.jetbrains.com/plugin/13710-chinese-simplified-language-pack----/ 

找到vm文件 对照正确地址填写 保存 即可！！！

许可证获取：https://jetbra.in/s

许可证服务器---可能废弃
http://49.234.70.205
http://60.247.72.31:8888
http://91.210.51.48:8080
http://34.206.48.129
http://13.232.35.56
http://153.106.195.23:8080
http://158.193.243.40
http://200.13.89.3:8080
http://140.238.85.244:8080
http://193.6.57.174:8080
http://150.254.118.138:8080
http://195.208.239.74
http://193.2.42.18:8080
http://200.17.85.220
http://186.211.99.100
http://212.73.75.141
http://203.23.253.45:8081
http://129.22.25.52
http://20.24.96.101
http://194.83.68.123
http://46.248.165.184:7777
http://80.169.232.216:8080
http://185.76.145.167:8080
http://94.100.93.228:8080
http://216.118.207.58:8181
http://62.76.124.130:8081
http://178.124.205.99:8090
http://185.14.45.25:8282
http://license.engr.ship.edu:8080
http://licence.fit.cvut.cz:9000
https://jblicense2.wappworks.com
https://jetbrains-license.learning.casareal.co.jp
https://license.fahai.org
https://lic.gotoweb.top
https://flm.nighthawkcodingsociety.com
https://fls-jetbrains.spacetechies.com
https://jbls.x-root.info
https://license-server.tmk.edu.hk
https://jenkins.wf-wolves.de
http://bumblebee.bhasvic.ac.uk
http://cse-lic-02.engineering.cwru.edu
http://lic-server.mephi.ru
http://license.runtime.kz
https://licenses.cerebotani.it
https://jetbrains.blackboard.com
http://adsk06.tpu.ru:8080
https://fls.aventus.work




食用方法: 
    1. 添加到vmoptions 参数 -javaagent:/路径/ja-netfilter.jar=jetbrains
    2. 退出登录的账号后 输入许可证 
    3. 许可证:
    https://jetbra.in/5d84466e31722979266057664941a71893322460
    https://bafybeigcfjpaajecjyohiamwycehko3w6lgan
    https://jetbra.in/s
    4. 自定义时间 插件'mymap' 已在2022.1版本弃用
    5. 不用担心激活时间 他不会失效

好好享受吧~

兼容Java17:（IDE2022.2版本默认启用Java17）具体看这里：https://openjdk.org/jeps/261
    添加到 vmoptions 不要出现任何空格！！！
    -opens=java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED
    -opens=java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED

新增功能: 
    自动 配置 vmoptions:
        macOS 或 Linux: 执行 "scripts/install.sh"
        Windows: 运行 "scripts\install-current-user.vbs" (当前用户)
                        "scripts\install-all-users.vbs" (所有用户)




